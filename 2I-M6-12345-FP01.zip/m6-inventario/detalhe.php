<?php
include "config.php";

$id = isset($_GET["id"]) ? (int)$_GET["id"] : 0;

// buscar dados do computador
$stmt = $pdo->prepare("SELECT * FROM computadores WHERE id_computador = ?");
$stmt->execute([$id]);
$pc = $stmt->fetch();

if (!$pc) {
  die("Computador não encontrado.");
}

// buscar software instalado
$stmt2 = $pdo->prepare("
  SELECT s.nome_software, s.versao
  FROM software s
  INNER JOIN computador_software cs ON s.id_software = cs.id_software
  WHERE cs.id_computador = ?
");
$stmt2->execute([$id]);
$softwares = $stmt2->fetchAll();
?>

<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="UTF-8">
<title>Detalhe - <?= htmlspecialchars($pc["nome_computador"]) ?></title>

<style>
* { box-sizing: border-box; }

body {
  margin: 0;
  font-family: "Segoe UI", Arial, sans-serif;
  background: linear-gradient(135deg, #667eea, #764ba2);
  min-height: 100vh;
}

.container {
  max-width: 900px;
  margin: 40px auto;
  background: #fff;
  border-radius: 15px;
  overflow: hidden;
  box-shadow: 0 20px 40px rgba(0,0,0,0.2);
}

.header {
  background: linear-gradient(135deg, #2c3e50, #4ca1af);
  color: white;
  padding: 25px 30px;
}

.header h1 { margin: 0; font-size: 26px; }

.content { padding: 25px 30px; }

.voltar {
  display: inline-block;
  margin-bottom: 15px;
  color: #4ca1af;
  text-decoration: none;
  font-weight: 500;
}
.voltar:hover { text-decoration: underline; }

.cards {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 15px;
  margin-bottom: 25px;
}

.card {
  background: #f7f9fc;
  padding: 15px 18px;
  border-radius: 12px;
  border-left: 6px solid #4ca1af;
}

.card h3 {
  margin: 0;
  font-size: 13px;
  color: #666;
}

.card p {
  margin: 6px 0 0;
  font-size: 15px;
  font-weight: bold;
  color: #333;
}

.section { margin-top: 30px; }

.section h2 { margin-bottom: 10px; color: #2c3e50; }

.software-box {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
}

.software-item {
  background: #e8f0fe;
  color: #2c3e50;
  padding: 8px 12px;
  border-radius: 20px;
  font-size: 14px;
  border: 1px solid #cfdcff;
}

.sem-software { color: #777; font-style: italic; }
</style>
</head>

<body>

<div class="container">

  <div class="header">
    <h1>💻 <?= htmlspecialchars($pc["nome_computador"]) ?></h1>
  </div>

  <div class="content">

    <a class="voltar" href="index.php">⬅ Voltar à lista</a>

    <div class="cards">
      <div class="card">
        <h3>Processador</h3>
        <p><?= htmlspecialchars($pc["processador"]) ?></p>
      </div>

      <div class="card">
        <h3>RAM</h3>
        <p><?= htmlspecialchars($pc["ram"]) ?></p>
      </div>

      <div class="card">
        <h3>Armazenamento</h3>
        <p><?= htmlspecialchars($pc["armazenamento"]) ?></p>
      </div>

      <div class="card">
        <h3>Placa Gráfica</h3>
        <p><?= htmlspecialchars($pc["placa_grafica"] ?? "Não definida") ?></p>
      </div>

      <div class="card">
        <h3>Sistema Operativo</h3>
        <p><?= htmlspecialchars($pc["sistema_operativo"]) ?></p>
      </div>
    </div>

    <div class="section">
      <h2>🖥 Software instalado</h2>

      <?php if (count($softwares) == 0): ?>
        <p class="sem-software">Não há software associado.</p>
      <?php else: ?>
        <div class="software-box">
          <?php foreach($softwares as $sw): ?>
            <div class="software-item">
              <?= htmlspecialchars($sw["nome_software"]) ?>
              <small>(<?= htmlspecialchars($sw["versao"]) ?>)</small>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>

  </div>
</div>

</body>
</html>
