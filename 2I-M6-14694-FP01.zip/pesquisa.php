<?php
// Página de pesquisa dinâmica (autocomplete) para computadores
include "config.php";
?>

<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Pesquisa - Inventário</title>
  	<style>
:root{
  --bg1:#6a7be6;
  --bg2:#7a63c9;
  --card:#ffffff;
  --primary:#4fa3b1;
  --primary-dark:#3b8b98;
  --text:#1f2937;
  --muted:#6b7280;
}

*{box-sizing:border-box}

body{
  margin:0;
  min-height:100vh;
  font-family: "Segoe UI", Tahoma, Arial, sans-serif;
  background: linear-gradient(135deg, var(--bg1), var(--bg2));
  display:flex;
  justify-content:center;
  align-items:flex-start;
  padding:40px 16px;
}

.wrap{
  width:100%;
  max-width:900px;
  background: var(--card);
  border-radius:18px;
  box-shadow:0 25px 60px rgba(0,0,0,.25);
  padding:28px 30px 32px;
}

a{
  text-decoration:none;
  color:var(--primary-dark);
  font-weight:600;
}

h1{
  margin:10px 0 6px;
  color:var(--text);
}

.hint{
  color:var(--muted);
  margin-bottom:14px;
}

.kbd{
  background:#eef2f7;
  border-radius:6px;
  padding:2px 6px;
  font-size:13px;
}

.search-row{
  position:relative;
  margin-top:10px;
}

input[type="text"]{
  width:100%;
  padding:14px 16px;
  font-size:16px;
  border:1px solid #e5e7eb;
  border-radius:12px;
  outline:none;
  transition:.2s;
}

input[type="text"]:focus{
  border-color:var(--primary);
  box-shadow:0 0 0 3px rgba(79,163,177,.25);
}

.results{
  position:absolute;
  top:calc(100% + 8px);
  left:0;
  right:0;
  background:#fff;
  border-radius:14px;
  box-shadow:0 20px 45px rgba(0,0,0,.18);
  overflow:hidden;
  display:none;
  z-index:50;
}

.item{
  padding:12px 14px;
  border-bottom:1px solid #f0f0f0;
  cursor:pointer;
  transition:.15s;
}

.item:last-child{border-bottom:none}

.item:hover{
  background:#f3f9fb;
}

.title{
  font-weight:700;
  color:#0f172a;
}

.meta{
  font-size:13px;
  color:#64748b;
  margin-top:2px;
}

.status{
  margin-top:10px;
  font-size:13px;
  color:#64748b;
}
</style>

    
</head>
<body>
  <div class="wrap">
    <a href="index.php">⬅ Voltar</a>
    <h1>Pesquisa de computadores</h1>

    <p class="hint">
      Escreve para pesquisar por <b>nome do computador</b>, <b>sistema operativo</b>, <b>processador</b> ou <b>software</b>.
      (Ex.: <span class="kbd">HP</span>, <span class="kbd">Windows</span>, <span class="kbd">Adobe</span>)
    </p>

    <div class="search-row">
      <input id="q" type="text" placeholder="Pesquisar..." autocomplete="off" />
      <div id="results" class="results" aria-live="polite"></div>
    </div>

    <div id="status" class="status"></div>
  </div>

  <script>
    const input = document.getElementById('q');
    const resultsBox = document.getElementById('results');
    const statusEl = document.getElementById('status');

    let debounceTimer = null;
    let lastQuery = '';
    let activeIndex = -1;

    function escapeHtml(str) {
      return String(str)
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#039;');
    }

    function hideResults() {
      resultsBox.style.display = 'none';
      resultsBox.innerHTML = '';
      activeIndex = -1;
    }

    function showResults(items) {
      if (!items || items.length === 0) {
        resultsBox.innerHTML = '<div class="item">Sem resultados encontrados.</div>';
        resultsBox.style.display = 'block';
        return;
      }

      resultsBox.innerHTML = items.map((it, idx) => {
        const title = escapeHtml(it.nome_computador);
        const sala = escapeHtml(it.nome_sala);
        const so = escapeHtml(it.sistema_operativo || '—');
        const ram = escapeHtml(it.ram || '—');
        return `
          <div class="item" data-idx="${idx}" data-id="${it.id_computador}">
            <div class="title">${title}</div>
            <div class="meta">Sala: ${sala} · SO: ${so} · RAM: ${ram}</div>
          </div>
        `;
      }).join('');

      resultsBox.style.display = 'block';

      // click
      resultsBox.querySelectorAll('.item').forEach(el => {
        const id = el.getAttribute('data-id');
        if (!id) return;
        el.addEventListener('click', () => {
          window.location.href = `detalhe.php?id=${encodeURIComponent(id)}`;
        });
      });
    }

    async function fetchResults(q) {
      if (q.trim().length < 2) {
        statusEl.textContent = 'Escreve pelo menos 2 caracteres…';
        hideResults();
        return;
      }

      statusEl.textContent = 'A procurar…';

      try {
        const res = await fetch(`api_pesquisa.php?q=${encodeURIComponent(q)}`);
        if (!res.ok) throw new Error('HTTP ' + res.status);
        const data = await res.json();

        // Evita atualizar a UI com respostas antigas
        if (q !== lastQuery) return;

        statusEl.textContent = `${data.length} resultado(s).`;
        showResults(data);
      } catch (e) {
        statusEl.textContent = 'Erro ao pesquisar. Verifica a ligação / servidor.';
        hideResults();
      }
    }

    input.addEventListener('input', () => {
      const q = input.value;
      lastQuery = q;

      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(() => fetchResults(q), 250);
    });

    // esconder ao clicar fora
    document.addEventListener('click', (ev) => {
      if (!resultsBox.contains(ev.target) && ev.target !== input) {
        hideResults();
      }
    });

    // navegação por teclado (opcional)
    input.addEventListener('keydown', (ev) => {
      const items = Array.from(resultsBox.querySelectorAll('.item[data-id]'));
      if (resultsBox.style.display === 'none' || items.length === 0) return;

      if (ev.key === 'ArrowDown') {
        ev.preventDefault();
        activeIndex = Math.min(activeIndex + 1, items.length - 1);
      } else if (ev.key === 'ArrowUp') {
        ev.preventDefault();
        activeIndex = Math.max(activeIndex - 1, 0);
      } else if (ev.key === 'Enter') {
        if (activeIndex >= 0) {
          ev.preventDefault();
          const id = items[activeIndex].getAttribute('data-id');
          if (id) window.location.href = `detalhe.php?id=${encodeURIComponent(id)}`;
        }
      } else {
        return;
      }

      items.forEach((el, i) => {
        el.style.background = (i === activeIndex) ? '#f0f0f0' : '';
      });
    });

    // foco inicial
    input.focus();
    statusEl.textContent = 'Escreve pelo menos 2 caracteres…';
  </script>
</body>
</html>