<?php
include "config.php";

// Buscar todas as salas
$salas = $pdo->query("SELECT * FROM salas")->fetchAll();

// Sala selecionada (null = todas)
$id_sala = isset($_GET["sala"]) && $_GET["sala"] != "" ? (int)$_GET["sala"] : null;

// Texto da pesquisa
$pesquisa = isset($_GET["pesquisa"]) ? trim($_GET["pesquisa"]) : "";

// ------------------ QUERY ------------------
if ($pesquisa != "") {

  // Pesquisa em todas as salas
  $stmt = $pdo->prepare("
    SELECT DISTINCT c.*
    FROM computadores c
    LEFT JOIN computador_software cs ON c.id_computador = cs.id_computador
    LEFT JOIN software s ON s.id_software = cs.id_software
    WHERE (
      c.nome_computador LIKE ?
      OR s.nome_software LIKE ?
      OR c.sistema_operativo LIKE ?
    )
  ");
  $like = "%$pesquisa%";
  $stmt->execute([$like, $like, $like]);

} elseif ($id_sala !== null) {

  // Filtrar por sala
  $stmt = $pdo->prepare("SELECT * FROM computadores WHERE id_sala = ?");
  $stmt->execute([$id_sala]);

} else {

  // Mostrar TODOS os computadores (todas as salas)
  $stmt = $pdo->query("SELECT * FROM computadores");

}

$computadores = $stmt->fetchAll();
$total_computadores = count($computadores);
?>

<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="UTF-8">
<title>Inventário de Computadores</title>

<style>
* { box-sizing: border-box; }

body {
  margin: 0;
  font-family: "Segoe UI", Arial, sans-serif;
  background: linear-gradient(135deg, #667eea, #764ba2);
  min-height: 100vh;
}

.container {
  max-width: 1000px;
  margin: 40px auto;
  background: #fff;
  border-radius: 15px;
  overflow: hidden;
  box-shadow: 0 20px 40px rgba(0,0,0,0.2);
}

.header {
  background: linear-gradient(135deg, #2c3e50, #4ca1af);
  color: white;
  padding: 25px 30px;
}

.header h1 { margin: 0; font-size: 28px; }

.content { padding: 25px 30px; }

form {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  align-items: center;
  margin-bottom: 20px;
}

select, input {
  padding: 10px 14px;
  border-radius: 8px;
  border: 1px solid #ccc;
  font-size: 15px;
}

button {
  padding: 10px 18px;
  border-radius: 8px;
  border: none;
  background: #4ca1af;
  color: white;
  font-size: 15px;
  cursor: pointer;
}

button:hover { background: #357f8c; }

.cards {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: 15px;
  margin-bottom: 25px;
}

.card {
  background: #f7f9fc;
  padding: 18px;
  border-radius: 12px;
  border-left: 6px solid #4ca1af;
}

.card h3 { margin: 0; font-size: 14px; color: #666; }
.card p { margin: 5px 0 0; font-size: 26px; font-weight: bold; }

.table-box { overflow-x: auto; }

table {
  width: 100%;
  border-collapse: collapse;
  border-radius: 10px;
  overflow: hidden;
}

th {
  background: #2c3e50;
  color: white;
  text-align: left;
  padding: 12px;
}

td {
  padding: 12px;
  border-bottom: 1px solid #eee;
}

tr:hover { background: #f1f5ff; }

a { color: #4ca1af; text-decoration: none; }
a:hover { text-decoration: underline; }

.sem-pcs { margin-top: 15px; color: #777; font-style: italic; }
</style>
</head>

<body>

<div class="container">

  <div class="header">
    <h1>💻 Inventário de Computadores</h1>
  </div>

  <div class="content">

    <form method="get" action="pesquisa.php">

      <strong>Sala:</strong>
      <select name="sala">
        <option value="">Todas as salas</option>
        <?php foreach($salas as $s): ?>
          <option value="<?= $s["id_sala"] ?>" <?= ($id_sala == $s["id_sala"]) ? "selected" : "" ?>>
            <?= $s["nome_sala"] ?>
          </option>
        <?php endforeach; ?>
      </select>

      <button type="submit">Pesquisar</button>

      <!-- Botão Pesquisa Avançada ao lado -->
      <a href="pesquisa.php"><button type="button">Pesquisa Avançada</button></a>

    </form>

    <div class="cards">
      <div class="card">
        <h3>Total de computadores</h3>
        <p><?= $total_computadores ?></p>
      </div>
    </div>

    <?php if($total_computadores > 0): ?>
    <div class="table-box">
      <table>
        <tr>
          <th>Nome</th>
          <th>Sistema Operativo</th>
          <th>RAM</th>
          <th>Ações</th>
        </tr>

        <?php foreach($computadores as $pc): ?>
        <tr>
          <td><?= htmlspecialchars($pc["nome_computador"]) ?></td>
          <td><?= htmlspecialchars($pc["sistema_operativo"]) ?></td>
          <td><?= htmlspecialchars($pc["ram"]) ?></td>
          <td>
            <a href="detalhe.php?id=<?= $pc["id_computador"] ?>">Ver detalhes ➜</a>
          </td>
        </tr>
        <?php endforeach; ?>
      </table>
    </div>
    <?php else: ?>
      <p class="sem-pcs">Nenhum computador encontrado.</p>
    <?php endif; ?>

  </div>
</div>

</body>
</html>
