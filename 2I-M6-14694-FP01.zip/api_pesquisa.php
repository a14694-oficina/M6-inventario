<?php
// Endpoint AJAX: devolve resultados em JSON
header('Content-Type: application/json; charset=utf-8');

require_once "config.php";

$q = isset($_GET['q']) ? trim($_GET['q']) : '';

if (mb_strlen($q) < 2) {
  echo json_encode([]);
  exit;
}

// Proteção simples: limita tamanho para evitar abusos
if (mb_strlen($q) > 60) {
  $q = mb_substr($q, 0, 60);
}

try {
  $like = "%" . $q . "%";

  $sql = "
    SELECT DISTINCT
      c.id_computador,
      c.nome_computador,
      c.sistema_operativo,
      c.ram,
      sa.nome_sala
    FROM computadores c
    INNER JOIN salas sa ON sa.id_sala = c.id_sala
    LEFT JOIN computador_software cs ON cs.id_computador = c.id_computador
    LEFT JOIN software sw ON sw.id_software = cs.id_software
    WHERE
      c.nome_computador LIKE :q
      OR c.processador LIKE :q
      OR c.sistema_operativo LIKE :q
      OR sw.nome_software LIKE :q
  ";

  $stmt = $pdo->prepare($sql);
  $stmt->bindValue(':q', $like, PDO::PARAM_STR);
  $stmt->execute();

  $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

  // (o cliente também faz escape)
  foreach ($rows as &$r) {
    foreach ($r as $k => $v) {
      if (is_string($v)) $r[$k] = trim($v);
    }
  }

  echo json_encode($rows, JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['error' => 'Erro no servidor']);
}
